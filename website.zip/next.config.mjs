/** @type {import('next').NextConfig} */
const nextConfig = {
    compress: false,
};

export default nextConfig;
